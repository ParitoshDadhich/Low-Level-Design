package parkingLotSystem.priceStrategy;

public interface PriceStrategy {
    double price();
}
