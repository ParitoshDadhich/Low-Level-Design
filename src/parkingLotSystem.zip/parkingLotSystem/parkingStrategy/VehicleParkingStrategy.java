package parkingLotSystem.parkingStrategy;

public interface VehicleParkingStrategy {
    void parkVehicle();
}
