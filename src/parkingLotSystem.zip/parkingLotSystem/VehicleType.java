package parkingLotSystem;

public enum VehicleType {
    two_wheel_vehicle,
    four_wheel_vehicle
}
