package parkingLotSystem.costComputation;

public interface CostComputation {
    double price(double timeSpendInParkingLot);
}
